package io.tl.nekopanel

import android.content.Context

class SettingsManager(context: Context) {
    private val prefs = context.getSharedPreferences("mihomo_settings", Context.MODE_PRIVATE)

    // --- 新增：测速配置 ---
    var testUrl: String
        get() = prefs.getString("test_url", "http://www.gstatic.com/generate_204") ?: "http://www.gstatic.com/generate_204"
        set(value) = prefs.edit().putString("test_url", value).apply()

    var testTimeout: Int
        get() = prefs.getInt("test_timeout", 5000)
        set(value) = prefs.edit().putInt("test_timeout", value).apply()

    // --- 日志配置 ---
    var logLevel: String
        get() = prefs.getString("log_level", "info") ?: "info"
        set(value) = prefs.edit().putString("log_level", value).apply()

    // --- UI 配置 ---
    var groupColumnCount: Int
        get() = prefs.getInt("group_column_count", 1)
        set(value) = prefs.edit().putInt("group_column_count", value).apply()

    var columnCount: Int
        get() = prefs.getInt("column_count", 2)
        set(value) = prefs.edit().putInt("column_count", value).apply()

    var groupBadgeStyle: String
        get() = prefs.getString("group_badge_style", "填充") ?: "填充"
        set(value) = prefs.edit().putString("group_badge_style", value).apply()

    var delayBadgeStyle: String
        get() = prefs.getString("delay_badge_style", "描边") ?: "描边"
        set(value) = prefs.edit().putString("delay_badge_style", value).apply()

    var badgeCornerRadius: Int
        get() = prefs.getInt("badge_corner_radius", 8)
        set(value) = prefs.edit().putInt("badge_corner_radius", value).apply()

    var showGlobal: Boolean
        get() = prefs.getBoolean("show_global", true)
        set(value) = prefs.edit().putBoolean("show_global", value).apply()

    var useSheetMode: Boolean
        get() = prefs.getBoolean("use_sheet_mode", false)
        set(value) = prefs.edit().putBoolean("use_sheet_mode", value).apply()

    var cardFillStyle: Boolean
        get() = prefs.getBoolean("card_fill_style", false)
        set(value) = prefs.edit().putBoolean("card_fill_style", value).apply()
}
