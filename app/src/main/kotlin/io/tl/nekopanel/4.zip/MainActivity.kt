package io.tl.nekopanel

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import io.tl.nekopanel.ui.theme.ComposeEmptyActivityTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.*
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

// ---------------- API ----------------

interface ClashApi {
    @GET("/proxies") suspend fun getProxies(): ProxyResponse
    @PUT("/proxies/{name}") suspend fun updateProxy(@Path("name") gName: String, @Body body: Map<String, String>): retrofit2.Response<Unit>
    
    // 改进：增加 timeout 参数，保证测速接口不会返回 Body invalid
    @GET("/proxies/{name}/delay") suspend fun getProxyDelay(
        @Path("name") name: String, 
        @Query("url") url: String, 
        @Query("timeout") timeout: Int
    ): DelayResponse
    
    @GET("/group/{name}/delay") suspend fun getGroupDelay(
        @Path("name") name: String, 
        @Query("url") url: String, 
        @Query("timeout") timeout: Int
    ): Map<String, Int>
    
    @GET("/configs") suspend fun getConfigs(): Map<String, Any>
    @PATCH("/configs") suspend fun updateConfigs(@Body body: Map<String, @JvmSuppressWildcards Any>): retrofit2.Response<Unit>

    data class ProxyResponse(val proxies: Map<String, ProxyItem>)
    data class ProxyItem(val name: String = "", val type: String, val now: String? = null, val all: List<String>? = null, val icon: String? = null, val history: List<History>? = null)
    data class History(val delay: Int)
    data class DelayResponse(val delay: Int)
}

object RetrofitClient {
    const val BASE_URL = "http://127.0.0.1:9090"
    val instance: ClashApi by lazy {
        Retrofit.Builder().baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create()).build().create(ClashApi::class.java)
    }
    val okHttpClient = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).build()
}

data class ConnectionItem(val id: String, val host: String, val network: String, val proxy: String, val upload: Long, val download: Long)
data class LogItem(val type: String, val payload: String, val time: Long = System.currentTimeMillis())

// ---------------- Main ----------------

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { ComposeEmptyActivityTheme { ClashManagerApp() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClashManagerApp() {
    val context = LocalContext.current
    val settings = remember { SettingsManager(context) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var showConfig by remember { mutableStateOf(false) }
    var showLogConfig by remember { mutableStateOf(false) }
    var globalRefreshTick by remember { mutableLongStateOf(0L) }
    var configUpdateTrigger by remember { mutableIntStateOf(0) }
    val logs = remember { mutableStateListOf<LogItem>() }
    val scope = rememberCoroutineScope()

    var currentMode by remember { mutableStateOf("rule") }
    LaunchedEffect(globalRefreshTick, configUpdateTrigger) {
        try {
            val config = RetrofitClient.instance.getConfigs()
            currentMode = config["mode"]?.toString() ?: "rule"
        } catch (e: Exception) {}
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("NekoPanel", fontWeight = FontWeight.Black) },
                actions = {
                    when (selectedTab) {
                        0 -> {
                            IconButton(onClick = { globalRefreshTick = System.currentTimeMillis() }) { Icon(Icons.Default.Refresh, null) }
                            IconButton(onClick = { showConfig = true }) { Icon(Icons.Default.Tune, null) }
                        }
                        2 -> {
                            IconButton(onClick = { logs.clear() }) { Icon(Icons.Default.LayersClear, null) }
                            IconButton(onClick = { showLogConfig = true }) { Icon(Icons.Default.FilterList, null) }
                        }
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                val navItems = listOf(
                    Triple("代理", Icons.AutoMirrored.Filled.List, 0),
                    Triple("连接", Icons.Default.SwapCalls, 1),
                    Triple("日志", Icons.Default.Terminal, 2),
                    Triple("设置", Icons.Default.Settings, 3)
                )
                navItems.forEach { (label, icon, index) ->
                    NavigationBarItem(selected = selectedTab == index, onClick = { selectedTab = index }, icon = { Icon(icon, null) }, label = { Text(label) })
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            key(configUpdateTrigger, selectedTab) {
                when (selectedTab) {
                    0 -> ProxiesScreen(settings, globalRefreshTick, currentMode) { globalRefreshTick = System.currentTimeMillis() }
                    1 -> ConnectionsScreen()
                    2 -> LogsScreen(logs, settings)
                    else -> FullSettingsScreen(settings)
                }
            }
        }
        if (showConfig) {
            ConfigBottomSheet(settings, onDismiss = { showConfig = false }, onUpdate = { configUpdateTrigger++ })
        }
        if (showLogConfig) {
            LogSettingsBottomSheet(settings, onDismiss = { showLogConfig = false }, onUpdate = { configUpdateTrigger++ })
        }
    }
}

// ---------------- 页面 ----------------

@Composable
fun LogsScreen(logs: SnapshotStateList<LogItem>, settings: SettingsManager) {
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    LaunchedEffect(settings.logLevel) {
        val request = Request.Builder().url("${RetrofitClient.BASE_URL}/logs?level=${settings.logLevel}").build()
        val ws = RetrofitClient.okHttpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val obj = JSONObject(text)
                    val item = LogItem(obj.getString("type"), obj.getString("payload"))
                    scope.launch(Dispatchers.Main) {
                        logs.add(item)
                        if (logs.size > 1000) logs.removeAt(0)
                        listState.animateScrollToItem(logs.size)
                    }
                } catch (e: Exception) {}
            }
        })
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                itemsIndexed(logs) { index: Int, log: LogItem ->
                    Column {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                            Text(
                                text = log.type.uppercase(),
                                color = when(log.type.lowercase()) {
                                    "info" -> MaterialTheme.colorScheme.primary
                                    "warning" -> Color(0xFFF57C00)
                                    "error" -> MaterialTheme.colorScheme.error
                                    "debug" -> MaterialTheme.colorScheme.tertiary
                                    else -> MaterialTheme.colorScheme.secondary
                                },
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.width(60.dp)
                            )
                            Text(
                                text = log.payload,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, lineHeight = 14.sp),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        if (index < logs.size - 1) {
                            HorizontalDivider(
                                modifier = Modifier.padding(horizontal = 12.dp),
                                thickness = 0.5.dp,
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProxiesScreen(settings: SettingsManager, refreshTick: Long, currentMode: String, onRefresh: () -> Unit) {
    var allProxies by remember { mutableStateOf<Map<String, ClashApi.ProxyItem>>(emptyMap()) }
    var isLoading by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(refreshTick) {
        try {
            val response = RetrofitClient.instance.getProxies()
            allProxies = response.proxies.mapValues { it.value.copy(name = it.key) }
        } catch (e: Exception) {}
        isLoading = false
    }

    if (isLoading) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
    } else {
        val isGlobalMode = currentMode.lowercase() == "global"
        val displayGroups = if (isGlobalMode) {
            allProxies.filter { it.key == "GLOBAL" }.toList()
        } else {
            val filtered = allProxies.filter { it.value.all != null }.toMutableMap()
            if (!settings.showGlobal) filtered.remove("GLOBAL")
            filtered.toList().sortedBy { it.first }
        }

        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                ModeSpinner(currentMode) { newMode ->
                    scope.launch(Dispatchers.IO) {
                        RetrofitClient.instance.updateConfigs(mapOf("mode" to newMode))
                        launch(Dispatchers.Main) { onRefresh() }
                    }
                }
            }
            
            if (settings.groupColumnCount == 1 || isGlobalMode) {
                LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(displayGroups, key = { it.first }) { (name, group) ->
                        ProxyGroupCard(name, group, allProxies, settings, onRefresh)
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(displayGroups, key = { it.first }) { (name, group) ->
                        ProxyGroupCard(name, group, allProxies, settings, onRefresh)
                    }
                }
            }
        }
    }
}

// ---------------- UI 组件 ----------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LogSettingsBottomSheet(settings: SettingsManager, onDismiss: () -> Unit, onUpdate: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 24.dp).padding(bottom = 32.dp)) {
            Text("日志设置", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(24.dp))
            val levels = listOf("info", "warning", "error", "debug", "silent")
            SettingsDropdownMenu(
                label = "监听等级",
                currentValue = settings.logLevel,
                options = levels
            ) {
                settings.logLevel = it
                onUpdate()
            }
            Spacer(Modifier.height(16.dp))
            Text("说明：切换等级会重新连接日志服务，旧日志将保留。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsDropdownMenu(label: String, currentValue: String, options: List<String>, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
        Box(modifier = Modifier.width(140.dp)) {
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                OutlinedTextField(
                    value = currentValue, onValueChange = {}, readOnly = true,
                    textStyle = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium),
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    modifier = Modifier.menuAnchor(), shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent)
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    options.forEach { option ->
                        DropdownMenuItem(text = { Text(option, fontSize = 13.sp) }, onClick = { onSelected(option); expanded = false })
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProxyGroupCard(name: String, group: ClashApi.ProxyItem, allProxies: Map<String, ClashApi.ProxyItem>, settings: SettingsManager, onUpdated: () -> Unit) {
    var isExpanded by remember { mutableStateOf(false) }
    var isTesting by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val currentDelay = allProxies[group.now]?.history?.lastOrNull()?.delay ?: 0
    val usePopup = settings.groupColumnCount == 2 || settings.useSheetMode

    Card(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)),
        onClick = { if (usePopup) isExpanded = true else isExpanded = !isExpanded },
        colors = CardDefaults.cardColors(containerColor = if (settings.cardFillStyle) MaterialTheme.colorScheme.surfaceVariant.copy(0.3f) else MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ProxyIconContainer(url = group.icon, fallbackText = name)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Black, maxLines = 1)
                    Text(group.now ?: "-", modifier = Modifier.basicMarquee(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline, maxLines = 1)
                }
                if (settings.groupColumnCount == 1) {
                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        TypeBadge(group.type, settings.groupBadgeStyle, settings.badgeCornerRadius, false)
                        DelayBadge(currentDelay, isTesting, settings.delayBadgeStyle, settings.badgeCornerRadius, false) {
                            scope.launch { 
                                isTesting = true
                                try { 
                                    // 改进：传入 URL 和 Timeout
                                    RetrofitClient.instance.getGroupDelay(name, settings.testUrl, settings.testTimeout) 
                                    delay(300) 
                                    onUpdated() 
                                } catch (e: Exception) {} finally { isTesting = false } 
                            }
                        }
                    }
                }
            }
            if (settings.groupColumnCount == 2) {
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    TypeBadge(group.type, settings.groupBadgeStyle, settings.badgeCornerRadius, true)
                    DelayBadge(currentDelay, isTesting, settings.delayBadgeStyle, settings.badgeCornerRadius, true) {
                        scope.launch { 
                            isTesting = true
                            try { 
                                // 改进：传入 URL 和 Timeout
                                RetrofitClient.instance.getGroupDelay(name, settings.testUrl, settings.testTimeout) 
                                delay(300) 
                                onUpdated() 
                            } catch (e: Exception) {} finally { isTesting = false } 
                        }
                    }
                }
            }
            if (!usePopup) {
                AnimatedVisibility(visible = isExpanded) { NodeGridSection(name, group, allProxies, settings, onUpdated) }
            }
        }
    }

    if (usePopup && isExpanded) {
        if (settings.useSheetMode) {
            ModalBottomSheet(onDismissRequest = { isExpanded = false }) {
                Box(Modifier.padding(16.dp).fillMaxHeight(0.7f)) { NodeGridSection(name, group, allProxies, settings, onUpdated) }
            }
        } else {
            Dialog(onDismissRequest = { isExpanded = false }) {
                Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth().fillMaxHeight(0.8f)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(12.dp))
                        NodeGridSection(name, group, allProxies, settings, onUpdated)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModeSpinner(currentMode: String, onModeSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val modes = listOf("rule" to "规则模式", "global" to "全局模式", "direct" to "直连模式")
    Box {
        FilterChip(
            selected = true, onClick = { expanded = true },
            label = { Text(modes.find { it.first == currentMode }?.second ?: currentMode, fontSize = 12.sp, fontWeight = FontWeight.Bold) },
            trailingIcon = { Icon(Icons.Default.ArrowDropDown, null, Modifier.size(16.dp)) },
            shape = RoundedCornerShape(12.dp)
        )
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            modes.forEach { (key, label) ->
                DropdownMenuItem(text = { Text(label) }, onClick = { onModeSelected(key); expanded = false })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NodeGridSection(groupName: String, group: ClashApi.ProxyItem, allProxies: Map<String, ClashApi.ProxyItem>, settings: SettingsManager, onUpdated: () -> Unit) {
    val scope = rememberCoroutineScope()
    LazyVerticalGrid(
        columns = GridCells.Fixed(settings.columnCount),
        modifier = Modifier.padding(top = 16.dp).heightIn(max = 450.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        itemsIndexed(group.all ?: emptyList(), key = { i, name -> "$groupName-$name-$i" }) { _, nodeName ->
            val nodeInfo = allProxies[nodeName]
            var isNodeTesting by remember { mutableStateOf(false) }
            NodeCard(
                name = nodeName, type = nodeInfo?.type ?: "Proxy",
                lastDelay = nodeInfo?.history?.lastOrNull()?.delay ?: 0,
                isSelected = nodeName == group.now, isTesting = isNodeTesting, settings = settings,
                onClick = { scope.launch { if (RetrofitClient.instance.updateProxy(groupName, mapOf("name" to nodeName)).isSuccessful) onUpdated() } },
                onRefreshDelay = { 
                    scope.launch { 
                        isNodeTesting = true
                        try { 
                            // 改进：传入 URL 和 Timeout
                            RetrofitClient.instance.getProxyDelay(nodeName, settings.testUrl, settings.testTimeout) 
                            delay(300) 
                            onUpdated() 
                        } catch (e: Exception) {} finally { isNodeTesting = false } 
                    } 
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DelayBadge(delay: Int, isTesting: Boolean, style: String, cornerRadius: Int, isFixedSize: Boolean, onClick: () -> Unit) {
    val color = when { isTesting -> MaterialTheme.colorScheme.primary; delay <= 0 -> MaterialTheme.colorScheme.outline; delay < 200 -> Color(0xFF388E3C); delay < 500 -> Color(0xFFF57C00); else -> Color(0xFFD32F2F) }
    val displayText = if (isTesting) "TESTING..." else if (delay <= 0) "TEST" else "${delay}ms"
    Surface(
        modifier = (if (isFixedSize) Modifier.width(60.dp).height(20.dp) else Modifier.wrapContentSize()).clip(RoundedCornerShape(cornerRadius.dp)).clickable(enabled = !isTesting, onClick = onClick, interactionSource = remember { MutableInteractionSource() }, indication = ripple()),
        color = if (style == "填充") (if (isTesting) color.copy(0.6f) else color) else Color.Transparent,
        shape = RoundedCornerShape(cornerRadius.dp),
        border = if (style == "描边") BorderStroke(1.dp, color.copy(if (isTesting) 0.5f else 1f)) else null
    ) {
        Box(contentAlignment = Alignment.Center, modifier = if (!isFixedSize) Modifier.padding(horizontal = 6.dp, vertical = 2.dp) else Modifier.fillMaxSize()) {
            Text(displayText, style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Black, platformStyle = PlatformTextStyle(includeFontPadding = false)), color = if (style == "填充") Color.White else color)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TypeBadge(text: String, style: String, cornerRadius: Int, isFixedSize: Boolean) {
    val color = MaterialTheme.colorScheme.primary
    Surface(color = if (style == "填充") color else Color.Transparent, shape = RoundedCornerShape(cornerRadius.dp), border = if (style == "描边") BorderStroke(1.dp, color) else null, modifier = if (isFixedSize) Modifier.width(60.dp).height(20.dp) else Modifier.wrapContentSize()) {
        Box(contentAlignment = Alignment.Center, modifier = if (!isFixedSize) Modifier.padding(horizontal = 6.dp, vertical = 2.dp) else Modifier.fillMaxSize()) {
            Text(text.uppercase(), style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Black, platformStyle = PlatformTextStyle(includeFontPadding = false)), color = if (style == "填充") Color.White else color)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NodeCard(name: String, type: String, lastDelay: Int, isSelected: Boolean, isTesting: Boolean, settings: SettingsManager, onClick: () -> Unit, onRefreshDelay: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else if (settings.cardFillStyle) MaterialTheme.colorScheme.surfaceVariant.copy(0.4f) else MaterialTheme.colorScheme.surfaceColorAtElevation(4.dp))) {
        Box(Modifier.padding(10.dp).fillMaxWidth().height(54.dp)) {
            Text(name, Modifier.align(Alignment.TopStart).fillMaxWidth().basicMarquee(), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, maxLines = 1)
            Row(Modifier.align(Alignment.BottomStart).fillMaxWidth(), Arrangement.SpaceBetween, Alignment.Bottom) {
                Text(type, fontSize = 9.sp, color = MaterialTheme.colorScheme.outline)
                DelayBadge(lastDelay, isTesting, settings.delayBadgeStyle, settings.badgeCornerRadius, false, onRefreshDelay)
            }
        }
    }
}

@Composable
fun ProxyIconContainer(url: String?, fallbackText: String) {
    Box(modifier = Modifier.size(32.dp).clip(RoundedCornerShape(8.dp)).background(if (url.isNullOrBlank()) MaterialTheme.colorScheme.primaryContainer else Color.Transparent), contentAlignment = Alignment.Center) {
        if (!url.isNullOrBlank()) AsyncImage(model = url, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.size(24.dp))
        else Text(fallbackText.take(1).uppercase(), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

@Composable
fun ConfigToggle(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    var state by remember(checked) { mutableStateOf(checked) }
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
        Switch(checked = state, onCheckedChange = { state = it; onCheckedChange(it) })
    }
}

@Composable
fun ConnectionsScreen() {
    var rawConnections by remember { mutableStateOf<List<Pair<ConnectionItem, String>>>(emptyList()) }
    var selectedJson by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        val request = Request.Builder().url("${RetrofitClient.BASE_URL}/connections?interval=1000").build()
        RetrofitClient.okHttpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val snapshot = JSONObject(text).getJSONArray("connections")
                    val newList = mutableListOf<Pair<ConnectionItem, String>>()
                    for (i in 0 until snapshot.length()) {
                        val obj = snapshot.getJSONObject(i)
                        val meta = obj.getJSONObject("metadata")
                        val item = ConnectionItem(obj.getString("id"), meta.optString("host").ifBlank { meta.optString("destinationIP") }, meta.optString("network"), obj.getJSONArray("chains").let { if(it.length()>0) it.getString(it.length()-1) else "Direct" }, obj.optLong("upload"), obj.optLong("download"))
                        newList.add(item to obj.toString(4))
                    }
                    scope.launch(Dispatchers.Main) { rawConnections = newList }
                } catch (e: Exception) {}
            }
        })
    }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("活跃连接: ${rawConnections.size}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                IconButton(onClick = { scope.launch(Dispatchers.IO) { RetrofitClient.okHttpClient.newCall(Request.Builder().url("${RetrofitClient.BASE_URL}/connections").delete().build()).execute() } }) { Icon(Icons.Default.DeleteSweep, null, tint = MaterialTheme.colorScheme.error) }
            }
        }
        items(rawConnections, key = { it.first.id }) { (conn, raw) ->
            Card(modifier = Modifier.fillMaxWidth().clickable { selectedJson = raw }, shape = RoundedCornerShape(12.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(conn.host, maxLines = 1, modifier = Modifier.basicMarquee(), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                        Text("${conn.network} • ${conn.proxy} | ↑${formatSize(conn.upload)} ↓${formatSize(conn.download)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    }
                    IconButton(onClick = { scope.launch(Dispatchers.IO) { RetrofitClient.okHttpClient.newCall(Request.Builder().url("${RetrofitClient.BASE_URL}/connections/${conn.id}").delete().build()).execute() } }) { Icon(Icons.Default.Close, null, Modifier.size(18.dp)) }
                }
            }
        }
    }
    if (selectedJson != null) {
        Dialog(onDismissRequest = { selectedJson = null }) {
            Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().fillMaxHeight(0.7f)) {
                Column(Modifier.padding(16.dp)) {
                    Text("元数据明细", fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                        SelectionContainer { Text(selectedJson!!, fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary, lineHeight = 14.sp) }
                    }
                    TextButton(onClick = { selectedJson = null }, Modifier.align(Alignment.End)) { Text("关闭") }
                }
            }
        }
    }
}

@Composable
fun FullSettingsScreen(settings: SettingsManager) {
    var config by remember { mutableStateOf<Map<String, Any>>(emptyMap()) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { try { config = RetrofitClient.instance.getConfigs() } catch (e: Exception) {} }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Text("系统设置", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black) }
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ConfigToggle("允许局域网连接", config["allow-lan"] as? Boolean ?: false) {
                        scope.launch(Dispatchers.IO) { RetrofitClient.instance.updateConfigs(mapOf("allow-lan" to it)) }
                    }
                    ConfigToggle("启用 IPv6 支持", config["ipv6"] as? Boolean ?: false) {
                        scope.launch(Dispatchers.IO) { RetrofitClient.instance.updateConfigs(mapOf("ipv6" to it)) }
                    }
                    ConfigToggle("流量嗅探 (Sniffing)", config["sniffing"] as? Boolean ?: false) {
                        scope.launch(Dispatchers.IO) { RetrofitClient.instance.updateConfigs(mapOf("sniffing" to it)) }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConfigBottomSheet(settings: SettingsManager, onDismiss: () -> Unit, onUpdate: () -> Unit) {
    // 改进：使用 Compose 的 local state 使得 TextField 和 Slider 在拖动/输入时即时刷新，解决 UI 卡死不更新的问题
    var testUrlState by remember { mutableStateOf(settings.testUrl) }
    var testTimeoutState by remember { mutableIntStateOf(settings.testTimeout) }
    var badgeRadiusState by remember { mutableIntStateOf(settings.badgeCornerRadius) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 24.dp).padding(bottom = 32.dp).verticalScroll(rememberScrollState())) {
            
            Text("测速设置", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(16.dp))
            
            OutlinedTextField(
                value = testUrlState,
                onValueChange = { 
                    testUrlState = it
                    settings.testUrl = it
                    onUpdate() 
                },
                label = { Text("测速地址", style = MaterialTheme.typography.labelSmall) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )
            Spacer(Modifier.height(16.dp))
            
            Text("测速超时: ${testTimeoutState}ms", style = MaterialTheme.typography.bodySmall)
            Slider(
                value = testTimeoutState.toFloat(),
                onValueChange = { 
                    testTimeoutState = it.toInt()
                    settings.testTimeout = testTimeoutState
                    onUpdate() 
                },
                valueRange = 1000f..10000f,
                steps = 8
            )

            HorizontalDivider(Modifier.padding(vertical = 16.dp), thickness = 0.5.dp)
            
            Text("UI 偏好设置", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(24.dp))
            SettingsDropdownMenu("代理组布局", if(settings.groupColumnCount == 1) "1 列" else "2 列", listOf("1 列", "2 列")) { settings.groupColumnCount = if(it=="1 列") 1 else 2; onUpdate() }
            SettingsDropdownMenu("节点网格列数", if(settings.columnCount == 1) "1 列" else "2 列", listOf("1 列", "2 列")) { settings.columnCount = if(it=="1 列") 1 else 2; onUpdate() }
            SettingsDropdownMenu("代理组卡片风格", settings.groupBadgeStyle, listOf("填充", "描边")) { settings.groupBadgeStyle = it; onUpdate() }
            SettingsDropdownMenu("延迟 Badge 风格", settings.delayBadgeStyle, listOf("填充", "描边")) { settings.delayBadgeStyle = it; onUpdate() }
            HorizontalDivider(Modifier.padding(vertical = 12.dp), thickness = 0.5.dp)
            ConfigToggle("显示 GLOBAL 组", settings.showGlobal) { settings.showGlobal = it; onUpdate() }
            ConfigToggle("点击开启抽屉模式", settings.useSheetMode) { settings.useSheetMode = it; onUpdate() }
            ConfigToggle("扁平卡片填充", settings.cardFillStyle) { settings.cardFillStyle = it; onUpdate() }
            Spacer(Modifier.height(16.dp))
            
            Text("Badge 圆角: ${badgeRadiusState}dp", style = MaterialTheme.typography.labelSmall)
            Slider(
                value = badgeRadiusState.toFloat(), 
                onValueChange = { 
                    badgeRadiusState = it.toInt()
                    settings.badgeCornerRadius = badgeRadiusState
                    onUpdate() 
                }, 
                valueRange = 0f..12f, 
                steps = 12
            )
        }
    }
}

fun formatSize(b: Long): String = when { b < 1024 -> "${b}B"; b < 1048576 -> "${String.format("%.1f", b/1024f)}K"; else -> "${String.format("%.1f", b/1048576f)}M" }
