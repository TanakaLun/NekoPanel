package io.tl.nekopanel

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.GraphicsLayerScope
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.*
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import com.google.gson.annotations.SerializedName
import retrofit2.http.*
import java.util.concurrent.TimeUnit
import io.tl.nekopanel.ui.theme.ComposeEmptyActivityTheme

// ---------------- API ----------------

interface ClashApi {
    @GET("/proxies") suspend fun getProxies(): ProxyResponse
    @PUT("/proxies/{name}") suspend fun updateProxy(@Path("name") gName: String, @Body body: Map<String, String>): retrofit2.Response<Unit>
    @GET("/proxies/{name}/delay") suspend fun getProxyDelay(@Path("name") name: String, @Query("url") url: String, @Query("timeout") timeout: Int): DelayResponse
    @GET("/group/{name}/delay") suspend fun getGroupDelay(@Path("name") name: String, @Query("url") url: String, @Query("timeout") timeout: Int): Map<String, Int>
    @GET("/configs") suspend fun getConfigs(): Map<String, Any>
    @PATCH("/configs") suspend fun updateConfigs(@Body body: Map<String, @JvmSuppressWildcards Any>): retrofit2.Response<Unit>
    @PUT("/configs") suspend fun reloadConfigs(@Body body: Map<String, String>): retrofit2.Response<Unit>
    
    @GET("/rules") suspend fun getRules(): RuleResponse
    @PATCH("/rules/disable") suspend fun updateRulesDisable(@Body body: Map<String, Boolean>): retrofit2.Response<Unit>

    // 新增：重启核心接口
    @POST("/restart") suspend fun restartCore(): retrofit2.Response<Unit>
    
    @GET("/version") suspend fun getVersion(): Map<String, Any>

    data class ProxyResponse(
        @SerializedName("proxies") val proxies: Map<String, ProxyItem>
    )
    
    data class ProxyItem(
        @SerializedName("name") val name: String = "",
        @SerializedName("type") val type: String,
        @SerializedName("now") val now: String? = null,
        @SerializedName("all") val all: List<String>? = null,
        @SerializedName("icon") val icon: String? = null,
        @SerializedName("history") val history: List<History>? = null
    )

    data class History(
        @SerializedName("delay") val delay: Int
    )
    
    data class DelayResponse(
        @SerializedName("delay") val delay: Int
    )
    
    data class RuleResponse(
        @SerializedName("rules") val rules: List<RuleItem>
    )
    
    data class RuleItem(
        @SerializedName("index") val index: Int = 0,
        @SerializedName("type") val type: String = "",
        @SerializedName("payload") val payload: String = "",
        @SerializedName("proxy") val proxy: String = "",
        @SerializedName("extra") val extra: RuleExtra? = null
    )
    
    data class RuleExtra(
        @SerializedName("disabled") val disabled: Boolean = false,
        @SerializedName("hitCount") val hitCount: Int = 0,
        @SerializedName("missCount") val missCount: Int = 0
    )
    
    data class OverviewState(
        val memoryInUse: Long = 0,
        val trafficUp: Long = 0,
        val trafficDown: Long = 0,
        val topRules: List<ClashApi.RuleItem> = emptyList()
    )
    data class HistoryPoint(
        val value: Long,
        val timestamp: Long = System.currentTimeMillis()
    )
}

object RetrofitClient {
    const val BASE_URL = "http://127.0.0.1:9090"
    val instance: ClashApi by lazy {
        Retrofit.Builder().baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create()).build().create(ClashApi::class.java)
    }
    val okHttpClient = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).build()
}

data class ConnectionItem(val id: String, val host: String, val network: String, val proxy: String, val upload: Long, val download: Long)
data class LogItem(val type: String, val payload: String, val time: Long = System.currentTimeMillis())

fun buildLogWs(scope: CoroutineScope, level: String, logs: SnapshotStateList<LogItem>): WebSocket {
    val req = Request.Builder().url("${RetrofitClient.BASE_URL}/logs?level=$level").build()
    return RetrofitClient.okHttpClient.newWebSocket(req, object : WebSocketListener() {
        override fun onMessage(webSocket: WebSocket, text: String) {
            try {
                val obj = JSONObject(text)
                val item = LogItem(obj.getString("type"), obj.getString("payload"))
                scope.launch(Dispatchers.Main) {
                    logs.add(item)
                    if (logs.size > 1000) logs.removeAt(0)
                }
            } catch (e: Exception) {}
        }
    })
}

fun buildConnWs(scope: CoroutineScope, onUpdate: (List<Pair<ConnectionItem, String>>) -> Unit): WebSocket {
    val req = Request.Builder().url("${RetrofitClient.BASE_URL}/connections?interval=1000").build()
    return RetrofitClient.okHttpClient.newWebSocket(req, object : WebSocketListener() {
        override fun onMessage(webSocket: WebSocket, text: String) {
            try {
                val snapshot = JSONObject(text).getJSONArray("connections")
                val newList = mutableListOf<Pair<ConnectionItem, String>>()
                for (i in 0 until snapshot.length()) {
                    val obj = snapshot.getJSONObject(i)
                    val meta = obj.getJSONObject("metadata")
                    val item = ConnectionItem(obj.getString("id"), meta.optString("host").ifBlank { meta.optString("destinationIP") }, meta.optString("network"), obj.getJSONArray("chains").let { if(it.length()>0) it.getString(it.length()-1) else "Direct" }, obj.optLong("upload"), obj.optLong("download"))
                    newList.add(item to obj.toString(4))
                }
                scope.launch(Dispatchers.Main) { onUpdate(newList) }
            } catch (e: Exception) {}
        }
    })
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { 
            val context = LocalContext.current
            // 1. 持久化管理器
            val settings = remember { SettingsManager(context) }
            
            // 2. 将 pureBlackMode 转化为 Compose State，使其改变时触发重绘
            var pureBlackMode by remember { mutableStateOf(settings.pureBlackMode) }
            
            ComposeEmptyActivityTheme(
                pureBlackMode = pureBlackMode 
            ) {
                ClashManagerApp(
                    settings = settings,
                    onPureBlackToggle = { isEnabled ->
                        pureBlackMode = isEnabled
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClashManagerApp(settings: SettingsManager, onPureBlackToggle: (Boolean) -> Unit) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var trafficTab by remember { mutableIntStateOf(0) }
    var globalRefreshTick by remember { mutableLongStateOf(0L) }
    var configUpdateTrigger by remember { mutableIntStateOf(0) }
    
    val logs = remember { mutableStateListOf<LogItem>() }
    var rawConnections by remember { mutableStateOf<List<Pair<ConnectionItem, String>>>(emptyList()) }
    var currentMode by remember { mutableStateOf("rule") }

    // --- 全局监控状态 ---
    var globalInUse by remember { mutableLongStateOf(0L) }
    var globalDown by remember { mutableLongStateOf(0L) }
    var globalUp by remember { mutableLongStateOf(0L) }
    var totalDown by remember { mutableLongStateOf(0L) }
    var totalUp by remember { mutableLongStateOf(0L) }

    // 使用你定义的 rememberChartHistory
    val memHistory = rememberChartHistory(globalInUse)
    val downHistory = rememberChartHistory(globalDown)

    var currentLogLevel by remember { mutableStateOf(settings.logLevel) }

    // 全局数据流
    LaunchedEffect(settings.backgroundWebSocket, currentLogLevel) {
        if (settings.backgroundWebSocket) {
            val logWs = buildLogWs(this, currentLogLevel, logs)
            val connWs = buildConnWs(this) { rawConnections = it }
            val memWs = buildWebSocket(this, "/memory") { globalInUse = JSONObject(it).optLong("inuse") }
            val trafficWs = buildWebSocket(this, "/traffic") { json ->
                val obj = JSONObject(json)
                globalDown = obj.optLong("down")
                globalUp = obj.optLong("up")
                // 直接从 WS 消息中提取总量
                totalDown = obj.optLong("downTotal")
                totalUp = obj.optLong("upTotal")
            }
            // 累积流量轮询
            val trafficJob = launch {
                while(true) {
                    try {
                        val response = RetrofitClient.okHttpClient.newCall(Request.Builder().url("${RetrofitClient.BASE_URL}/traffic").build()).execute()
                        val json = JSONObject(response.body?.string() ?: "{}")
                        totalDown = json.optLong("downTotal")
                        totalUp = json.optLong("upTotal")
                    } catch(e: Exception) {}
                    kotlinx.coroutines.delay(3000)
                }
            }
            try { kotlinx.coroutines.delay(Long.MAX_VALUE) } finally { 
                logWs.cancel(); connWs.cancel(); memWs.cancel(); trafficWs.cancel(); trafficJob.cancel() 
            }
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    if (selectedTab == 2) {
                        CapsuleTabRow(
                            selectedTab = trafficTab,
                            onTabSelected = { trafficTab = it },
                            tabs = listOf("概览", "连接", "日志")
                        )
                    } else {
                        Text(
                            text = when (selectedTab) { 0 -> "代理"; 1 -> "规则"; 3 -> "设置"; else -> "NekoPanel" },
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                val navItems = listOf(
                    Triple("代理", Icons.AutoMirrored.Filled.List, 0), 
                    Triple("规则", Icons.Default.CheckCircle, 1),
                    Triple("监控", Icons.Default.SwapCalls, 2), 
                    Triple("设置", Icons.Default.Settings, 3)
                )
                navItems.forEach { (label, icon, index) -> 
                    NavigationBarItem(
                        selected = selectedTab == index, 
                        onClick = { selectedTab = index }, 
                        icon = { Icon(icon, null) }, 
                        label = { Text(label) }
                    ) 
                }
            }
        }
    ) { padding ->
        // 修正点：合并并清理了重复的 Box 和 when 逻辑
        Box(Modifier.padding(padding)) {
            key(configUpdateTrigger, selectedTab) {
                when (selectedTab) {
                    0 -> ProxiesScreen(settings, globalRefreshTick, currentMode, onRefresh = { globalRefreshTick = System.currentTimeMillis() }, onModeChange = { configUpdateTrigger++ })
                    1 -> RulesScreen(globalRefreshTick, settings)
                    2 -> TrafficScreen(
                        trafficTab, logs, rawConnections, settings, currentLogLevel,
                        globalInUse, globalDown, totalDown, totalUp, memHistory, downHistory,
                        onLevelChange = { currentLogLevel = it },
                        onConnectionsUpdate = { rawConnections = it }
                    )
                    else -> FullSettingsScreen(settings, onPureBlackToggle)
                }
            }
        }
    }
}

// ---------------- 页面 ----------------

@Composable
fun RulesScreen(refreshTick: Long, settings: SettingsManager) {
    var rules by remember { mutableStateOf<List<ClashApi.RuleItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    fun fetchRules() {
        scope.launch(Dispatchers.IO) {
            try {
                val res = RetrofitClient.instance.getRules().rules
                launch(Dispatchers.Main) { rules = res; isLoading = false }
            } catch (e: Exception) { launch(Dispatchers.Main) { isLoading = false } }
        }
    }

    LaunchedEffect(refreshTick) { fetchRules() }

    if (isLoading) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
    } else {
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(rules, key = { it.index }) { rule ->
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(0.3f))) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).padding(end = 12.dp)) {
                            Row(verticalAlignment = Alignment.Top) { // 解决多行文本重叠问题
                                TypeBadge(rule.type, settings.ruleBadgeStyle, settings.badgeCornerRadius, false)
                                Spacer(Modifier.width(8.dp))
                                // 动态高度文本，移除 maxLines 和 basicMarquee
                                Text(rule.payload, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, lineHeight = 18.sp)
                            }
                            Spacer(Modifier.height(6.dp))
                            Text("🎯 代理: ${rule.proxy}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                        }
                        val isDisabled = rule.extra?.disabled ?: false
                        Switch(
                            checked = !isDisabled,
                            onCheckedChange = { isChecked ->
                                scope.launch(Dispatchers.IO) {
                                    try { RetrofitClient.instance.updateRulesDisable(mapOf(rule.index.toString() to !isChecked)); fetchRules() } catch (e: Exception) {}
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TrafficScreen(
    trafficTab: Int,
    logs: SnapshotStateList<LogItem>, 
    connections: List<Pair<ConnectionItem, String>>,
    settings: SettingsManager, 
    currentLogLevel: String,
    // 传入状态
    memoryInUse: Long, trafficDown: Long, totalDown: Long, totalUp: Long,
    memHistory: List<Long>, downHistory: List<Long>,
    onLevelChange: (String) -> Unit, 
    onConnectionsUpdate: (List<Pair<ConnectionItem, String>>) -> Unit
) {
    var rules by remember { mutableStateOf<List<ClashApi.RuleItem>>(emptyList()) }
    LaunchedEffect(Unit) {
        while(true) {
            try { rules = RetrofitClient.instance.getRules().rules } catch (e: Exception) {}
            kotlinx.coroutines.delay(5000)
        }
    }

    // 处理非后台模式下的 WS
    LaunchedEffect(settings.backgroundWebSocket, currentLogLevel) {
        if (!settings.backgroundWebSocket) {
            val logWs = buildLogWs(this, currentLogLevel, logs)
            val connWs = buildConnWs(this, onConnectionsUpdate)
            try { kotlinx.coroutines.delay(Long.MAX_VALUE) } finally { logWs.cancel(); connWs.cancel() }
        }
    }

    when (trafficTab) {
        0 -> OverviewView(connections, rules, memoryInUse, trafficDown, totalDown, totalUp, memHistory, downHistory, settings)
        1 -> ConnectionsView(connections)
        2 -> LogsView(logs, currentLogLevel, onLevelChange)
    }
}


@Composable
fun LogsView(logs: SnapshotStateList<LogItem>, currentLogLevel: String, onLevelChange: (String) -> Unit) {
    val listState = rememberLazyListState()
    LaunchedEffect(logs.size) { if (logs.isNotEmpty()) listState.animateScrollToItem(logs.size - 1) }

    Column(Modifier.fillMaxSize()) {
        // --- 提取出 topbar 控件到内容区首行 ---
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).height(40.dp), verticalAlignment = Alignment.CenterVertically) {
            LevelSpinner(currentLogLevel) { onLevelChange(it) }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { logs.clear() }) { Icon(Icons.Default.DeleteSweep, null, tint = MaterialTheme.colorScheme.error) }
        }

        Surface(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp).padding(bottom = 16.dp),
            color = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp),
            shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
        ) {
            LazyColumn(state = listState, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 8.dp)) {
                itemsIndexed(logs) { index: Int, log: LogItem ->
                    Column {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                            Text(text = log.type.uppercase(), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black, modifier = Modifier.width(60.dp), color = when(log.type.lowercase()) { "info" -> MaterialTheme.colorScheme.primary; "warning" -> Color(0xFFF57C00); "error" -> MaterialTheme.colorScheme.error; "debug" -> MaterialTheme.colorScheme.tertiary; else -> MaterialTheme.colorScheme.secondary })
                            Text(text = log.payload, style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, lineHeight = 14.sp), color = MaterialTheme.colorScheme.onSurface)
                        }
                        if (index < logs.size - 1) HorizontalDivider(modifier = Modifier.padding(horizontal = 12.dp), thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    }
                }
            }
        }
    }
}

@Composable
fun ConnectionsView(connections: List<Pair<ConnectionItem, String>>) {
    var selectedJson by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().height(48.dp).padding(bottom = 8.dp), 
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("活跃连接: ${connections.size}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                IconButton(onClick = { 
                    scope.launch(Dispatchers.IO) { 
                        RetrofitClient.okHttpClient.newCall(Request.Builder().url("${RetrofitClient.BASE_URL}/connections").delete().build()).execute() 
                    } 
                }) { 
                    Icon(Icons.Default.DeleteSweep, null, tint = MaterialTheme.colorScheme.error) 
                }
            }
        }

        items(connections, key = { it.first.id }) { (conn, raw) ->
            Box(Modifier.clickable { selectedJson = raw }) {
                ConnectionCard(
                    conn = conn,
                    rawJson = raw,
                    onClose = {
                        scope.launch(Dispatchers.IO) {
                            RetrofitClient.okHttpClient.newCall(
                                Request.Builder().url("${RetrofitClient.BASE_URL}/connections/${conn.id}").delete().build()
                            ).execute()
                        }
                    }
                )
            }
        }
    }

    if (selectedJson != null) {
        Dialog(onDismissRequest = { selectedJson = null }) {
            Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().fillMaxHeight(0.7f)) {
                Column(Modifier.padding(16.dp)) {
                    Text("元数据明细", fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.weight(1f).verticalScroll(rememberScrollState())) { SelectionContainer { Text(selectedJson!!, fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary, lineHeight = 14.sp) } }
                    TextButton(onClick = { selectedJson = null }, Modifier.align(Alignment.End)) { Text("关闭") }
                }
            }
        }
    }
}

@Composable
fun OverviewView(
    rawConnections: List<Pair<ConnectionItem, String>>, 
    rules: List<ClashApi.RuleItem>,
    memoryInUse: Long,
    trafficDown: Long,
    totalDown: Long,
    totalUp: Long,
    memHistory: List<Long>,
    downHistory: List<Long>,
    settings: SettingsManager
) {
    val topRules = remember(rules) {
        rules.filter { (it.extra?.hitCount ?: 0) > 0 }
            .sortedByDescending { it.extra?.hitCount ?: 0 }
            .take(5)
    }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(0.3f))) {
                Column(Modifier.padding(16.dp)) {
                    Text("系统概览", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text("内存占用", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                            Text(formatSize(memoryInUse), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            MiniLineChart(memHistory, MaterialTheme.colorScheme.primary, Modifier.fillMaxWidth().height(40.dp).padding(top = 4.dp))
                        }
                        Column(Modifier.weight(1f)) {
                            Text("下载速度", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                            Text("${formatSize(trafficDown)}/s", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            MiniLineChart(downHistory, MaterialTheme.colorScheme.tertiary, Modifier.fillMaxWidth().height(40.dp).padding(top = 4.dp))
                        }
                    }
                    HorizontalDivider(Modifier.padding(vertical = 12.dp), thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Column {
                            Text("总下载", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                            Text(formatSize(totalDown), fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("总上传", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                            Text(formatSize(totalUp), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
                listOf("活跃连接" to "${rawConnections.size}", "规则命中" to "${rules.sumOf { it.extra?.hitCount ?: 0 }}").forEach { (label, value) ->
                    Card(Modifier.weight(1f), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))) {
                        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                            Text(value, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
        }

        item { Text("高频规则命中", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp)) }

        items(topRules) { rule ->
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f).padding(end = 8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TypeBadge(rule.type, settings.ruleBadgeStyle, settings.badgeCornerRadius, false)
                            Spacer(Modifier.width(8.dp))
                            Text(rule.payload, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, lineHeight = 18.sp)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text("➔ ${rule.proxy}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    }
                    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = CircleShape) {
                        Text("${rule.extra?.hitCount}", modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable
fun ProxiesScreen(settings: SettingsManager, refreshTick: Long, currentMode: String, onRefresh: () -> Unit, onModeChange: () -> Unit) {
    var allProxies by remember { mutableStateOf<Map<String, ClashApi.ProxyItem>>(emptyMap()) }
    var isLoading by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(refreshTick) {
        try { val response = RetrofitClient.instance.getProxies(); allProxies = response.proxies.mapValues { it.value.copy(name = it.key) } } catch (e: Exception) {}
        isLoading = false
    }

    if (isLoading) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
    } else {
        val isGlobalMode = currentMode.lowercase() == "global"
        val displayGroups = if (isGlobalMode) allProxies.filter { it.key == "GLOBAL" }.toList() else {
            val filtered = allProxies.filter { it.value.all != null }.toMutableMap()
            if (!settings.showGlobal) filtered.remove("GLOBAL")
            filtered.toList().sortedBy { it.first }
        }

        Column(Modifier.fillMaxSize()) {
            // --- 将所有按键布局在高度为40dp的同行中 ---
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).height(40.dp), verticalAlignment = Alignment.CenterVertically) {
                ModeSpinner(currentMode) { newMode ->
                    scope.launch(Dispatchers.IO) { RetrofitClient.instance.updateConfigs(mapOf("mode" to newMode)); launch(Dispatchers.Main) { onModeChange(); onRefresh() } }
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onRefresh) { Icon(Icons.Default.Speed, "全面测速", tint = MaterialTheme.colorScheme.primary) }
            }
            
            if (settings.groupColumnCount == 1 || isGlobalMode) {
                LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(displayGroups, key = { it.first }) { (name, group) -> ProxyGroupCard(name, group, allProxies, settings, onRefresh) }
                }
            } else {
                LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(displayGroups, key = { it.first }) { (name, group) -> ProxyGroupCard(name, group, allProxies, settings, onRefresh) }
                }
            }
        }
    }
}

// ---------------- UI 组件 ----------------
@Composable
fun CapsuleTabRow(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit,
    tabs: List<String>
) {
    val containerHeight = 40.dp
    val indicatorHeight = 32.dp
    val horizontalPadding = 16.dp // 每个 Tab 的内边距

    Surface(
        modifier = Modifier
            .wrapContentWidth()
            .height(containerHeight),
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
    ) {
        // 使用 Box 堆叠指示器和 Tab 内容
        Box(modifier = Modifier.padding(horizontal = 4.dp)) {
            Row(
                modifier = Modifier.fillMaxHeight(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                tabs.forEachIndexed { index, title ->
                    val isSelected = selectedTab == index
                    
                    // 动画处理，技术原因只搞了标签的缩放
                    val textScale by animateFloatAsState(
                        targetValue = if (isSelected) 1.05f else 1f,
                        label = "textScale"
                    )

                    Box(
                        modifier = Modifier
                            .height(indicatorHeight)
                            .wrapContentWidth()
                            .clip(CircleShape)
                            .background(
                                color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent
                            )
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { onTabSelected(index) }
                            .padding(horizontal = horizontalPadding), // 这里的 padding 决定了组件总宽度
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = title,
                            modifier = Modifier
                                .graphicsLayer {
                                    scaleX = textScale
                                    scaleY = textScale
                                },
                            // 强制反色逻辑，避免了对比度可读性问题
                            color = if (isSelected) 
                                MaterialTheme.colorScheme.onPrimary 
                            else 
                                MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 14.sp
                            ),
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModeSpinner(currentMode: String, onModeSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val modes = listOf("rule" to "规则模式", "global" to "全局模式", "direct" to "直连模式")
    Box {
        FilterChip(
            selected = true, onClick = { expanded = true },
            label = { Text(modes.find { it.first == currentMode }?.second ?: currentMode, fontSize = 12.sp, fontWeight = FontWeight.Bold) },
            trailingIcon = { Icon(Icons.Default.ArrowDropDown, null, Modifier.size(16.dp)) }, shape = RoundedCornerShape(12.dp)
        )
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            modes.forEach { (key, label) -> DropdownMenuItem(text = { Text(label) }, onClick = { onModeSelected(key); expanded = false }) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LevelSpinner(currentLevel: String, onLevelSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val levels = listOf("info", "warning", "error", "debug", "silent")
    Box {
        FilterChip(
            selected = true, onClick = { expanded = true },
            label = { Text(currentLevel.uppercase(), fontSize = 12.sp, fontWeight = FontWeight.Bold) },
            trailingIcon = { Icon(Icons.Default.ArrowDropDown, null, Modifier.size(16.dp)) }, shape = RoundedCornerShape(12.dp)
        )
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            levels.forEach { level -> DropdownMenuItem(text = { Text(level.uppercase()) }, onClick = { onLevelSelected(level); expanded = false }) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProxyGroupCard(name: String, group: ClashApi.ProxyItem, allProxies: Map<String, ClashApi.ProxyItem>, settings: SettingsManager, onUpdated: () -> Unit) {
    var isExpanded by remember { mutableStateOf(false) }
    var isTesting by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val currentDelay = allProxies[group.now]?.history?.lastOrNull()?.delay ?: 0
    val usePopup = settings.groupColumnCount == 2 || settings.useSheetMode

    Card(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)),
        onClick = { if (usePopup) isExpanded = true else isExpanded = !isExpanded },
        colors = CardDefaults.cardColors(containerColor = if (settings.cardFillStyle) MaterialTheme.colorScheme.surfaceVariant.copy(0.3f) else MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ProxyIconContainer(url = group.icon, fallbackText = name)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Black, maxLines = 1)
                    Text(group.now ?: "-", modifier = Modifier.basicMarquee(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline, maxLines = 1)
                }
                if (settings.groupColumnCount == 1) {
                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        TypeBadge(group.type, settings.groupBadgeStyle, settings.badgeCornerRadius, false)
                        DelayBadge(currentDelay, isTesting, settings.delayBadgeStyle, settings.badgeCornerRadius, false) {
                            scope.launch { isTesting = true; try { RetrofitClient.instance.getGroupDelay(name, settings.testUrl, settings.testTimeout); delay(300); onUpdated() } catch (e: Exception) {} finally { isTesting = false } }
                        }
                    }
                }
            }
            if (settings.groupColumnCount == 2) {
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    TypeBadge(group.type, settings.groupBadgeStyle, settings.badgeCornerRadius, true)
                    DelayBadge(currentDelay, isTesting, settings.delayBadgeStyle, settings.badgeCornerRadius, true) {
                        scope.launch { isTesting = true; try { RetrofitClient.instance.getGroupDelay(name, settings.testUrl, settings.testTimeout); delay(300); onUpdated() } catch (e: Exception) {} finally { isTesting = false } }
                    }
                }
            }
            if (!usePopup) AnimatedVisibility(visible = isExpanded) { NodeGridSection(name, group, allProxies, settings, onUpdated) }
        }
    }

    if (usePopup && isExpanded) {
        if (settings.useSheetMode) ModalBottomSheet(onDismissRequest = { isExpanded = false }) { Box(Modifier.padding(16.dp).fillMaxHeight(0.7f)) { NodeGridSection(name, group, allProxies, settings, onUpdated) } }
        else Dialog(onDismissRequest = { isExpanded = false }) { Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth().fillMaxHeight(0.8f)) { Column(Modifier.padding(16.dp)) { Text(name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black); Spacer(Modifier.height(12.dp)); NodeGridSection(name, group, allProxies, settings, onUpdated) } } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NodeGridSection(groupName: String, group: ClashApi.ProxyItem, allProxies: Map<String, ClashApi.ProxyItem>, settings: SettingsManager, onUpdated: () -> Unit) {
    val scope = rememberCoroutineScope()
    LazyVerticalGrid(columns = GridCells.Fixed(settings.columnCount), modifier = Modifier.padding(top = 16.dp).heightIn(max = 450.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        itemsIndexed(group.all ?: emptyList(), key = { i, name -> "$groupName-$name-$i" }) { _, nodeName ->
            val nodeInfo = allProxies[nodeName]
            var isNodeTesting by remember { mutableStateOf(false) }
            NodeCard(
                name = nodeName, type = nodeInfo?.type ?: "Proxy", lastDelay = nodeInfo?.history?.lastOrNull()?.delay ?: 0,
                isSelected = nodeName == group.now, isTesting = isNodeTesting, settings = settings,
                onClick = { scope.launch { if (RetrofitClient.instance.updateProxy(groupName, mapOf("name" to nodeName)).isSuccessful) onUpdated() } },
                onRefreshDelay = { scope.launch { isNodeTesting = true; try { RetrofitClient.instance.getProxyDelay(nodeName, settings.testUrl, settings.testTimeout); delay(300); onUpdated() } catch (e: Exception) {} finally { isNodeTesting = false } } }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DelayBadge(delay: Int, isTesting: Boolean, style: String, cornerRadius: Int, isFixedSize: Boolean, onClick: () -> Unit) {
    val color = when { isTesting -> MaterialTheme.colorScheme.primary; delay <= 0 -> MaterialTheme.colorScheme.outline; delay < 200 -> Color(0xFF388E3C); delay < 500 -> Color(0xFFF57C00); else -> Color(0xFFD32F2F) }
    val displayText = if (isTesting) "…..." else if (delay <= 0) "TEST" else "${delay}ms"
    Surface(modifier = (if (isFixedSize) Modifier.width(60.dp).height(20.dp) else Modifier.wrapContentSize()).clip(RoundedCornerShape(cornerRadius.dp)).clickable(enabled = !isTesting, onClick = onClick, interactionSource = remember { MutableInteractionSource() }, indication = ripple()), color = if (style == "填充") (if (isTesting) color.copy(0.6f) else color) else Color.Transparent, shape = RoundedCornerShape(cornerRadius.dp), border = if (style == "描边") BorderStroke(1.dp, color.copy(if (isTesting) 0.5f else 1f)) else null) {
        Box(contentAlignment = Alignment.Center, modifier = if (!isFixedSize) Modifier.padding(horizontal = 6.dp, vertical = 2.dp) else Modifier.fillMaxSize()) { Text(displayText, style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Black, platformStyle = PlatformTextStyle(includeFontPadding = false)), color = if (style == "填充") Color.White else color) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TypeBadge(text: String, style: String, cornerRadius: Int, isFixedSize: Boolean) {
    val color = MaterialTheme.colorScheme.primary
    Surface(color = if (style == "填充") color else Color.Transparent, shape = RoundedCornerShape(cornerRadius.dp), border = if (style == "描边") BorderStroke(1.dp, color) else null, modifier = if (isFixedSize) Modifier.width(60.dp).height(20.dp) else Modifier.wrapContentSize()) {
        Box(contentAlignment = Alignment.Center, modifier = if (!isFixedSize) Modifier.padding(horizontal = 6.dp, vertical = 2.dp) else Modifier.fillMaxSize()) { Text(text.uppercase(), style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Black, platformStyle = PlatformTextStyle(includeFontPadding = false)), color = if (style == "填充") Color.White else color) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NodeCard(name: String, type: String, lastDelay: Int, isSelected: Boolean, isTesting: Boolean, settings: SettingsManager, onClick: () -> Unit, onRefreshDelay: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else if (settings.cardFillStyle) MaterialTheme.colorScheme.surfaceVariant.copy(0.4f) else MaterialTheme.colorScheme.surfaceColorAtElevation(4.dp))) {
        Box(Modifier.padding(10.dp).fillMaxWidth().height(54.dp)) {
            Text(name, Modifier.align(Alignment.TopStart).fillMaxWidth().basicMarquee(), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, maxLines = 1)
            Row(Modifier.align(Alignment.BottomStart).fillMaxWidth(), Arrangement.SpaceBetween, Alignment.Bottom) {
                Text(type, fontSize = 9.sp, color = MaterialTheme.colorScheme.outline)
                DelayBadge(lastDelay, isTesting, settings.delayBadgeStyle, settings.badgeCornerRadius, false, onRefreshDelay)
            }
        }
    }
}

@Composable
fun ProxyIconContainer(url: String?, fallbackText: String) {
    Box(modifier = Modifier.size(32.dp).clip(RoundedCornerShape(8.dp)).background(if (url.isNullOrBlank()) MaterialTheme.colorScheme.primaryContainer else Color.Transparent), contentAlignment = Alignment.Center) {
        if (!url.isNullOrBlank()) AsyncImage(model = url, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.size(24.dp))
        else Text(fallbackText.take(1).uppercase(), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

@Composable
fun ConfigToggle(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).padding(end = 16.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsDropdownMenuInline(label: String, currentValue: String, options: List<String>, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text = label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
        Box(modifier = Modifier.width(140.dp)) {
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                OutlinedTextField(
                    value = currentValue, onValueChange = {}, readOnly = true, textStyle = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium),
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) }, modifier = Modifier.menuAnchor(), shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent)
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    options.forEach { option -> DropdownMenuItem(text = { Text(option, fontSize = 13.sp) }, onClick = { onSelected(option); expanded = false }) }
                }
            }
        }
    }
}

@Composable
fun ConnectionCard(
    conn: ConnectionItem,
    rawJson: String,
    onClose: () -> Unit
) {
    val startTimeMillis = remember(rawJson) {
        try {
            val startStr = JSONObject(rawJson).optString("start", "")
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                java.time.Instant.parse(startStr).toEpochMilli()
            } else {
                java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.getDefault()).apply {
                    timeZone = java.util.TimeZone.getTimeZone("UTC")
                }.parse(startStr)?.time ?: System.currentTimeMillis()
            }
        } catch (e: Exception) { System.currentTimeMillis() }
    }

    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // --- 左侧：信息主体 ---
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = conn.host,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    modifier = Modifier.basicMarquee()
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "${conn.network.uppercase()} · ${conn.proxy}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.outline
                )
            }

            Spacer(Modifier.width(12.dp))

            // --- 右侧：功能与统计垂直列 (已重构为双行结构) ---
            Column(
                horizontalAlignment = Alignment.End,
                modifier = Modifier.width(IntrinsicSize.Max) 
            ) {
                // 第一行：时长 + 断开按钮并排
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End
                ) {
                    DurationBadge(startTimeMillis)
                    
                    Spacer(Modifier.width(6.dp)) // 紧凑间距
                    
                    // 微型化按钮处理
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            Icons.Default.Close, 
                            contentDescription = "断开连接", 
                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                            modifier = Modifier.size(16.dp) // 稍微缩小图标，显得更精致
                        )
                    }
                }
            
                Spacer(Modifier.height(6.dp)) // 行间距
            
                // 第二行：上下行数据横向并排
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End
                ) {
                    // 上行数据
                    Icon(
                        imageVector = Icons.Default.ArrowUpward, 
                        contentDescription = null, 
                        modifier = Modifier.size(10.dp), 
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = formatSize(conn.upload), 
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(start = 2.dp)
                    )
                    
                    Spacer(Modifier.width(8.dp))
                    
                    // 下行数据
                    Icon(
                        imageVector = Icons.Default.ArrowDownward, 
                        contentDescription = null, 
                        modifier = Modifier.size(10.dp), 
                        tint = MaterialTheme.colorScheme.tertiary
                    )
                    Text(
                        text = formatSize(conn.download), 
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(start = 2.dp)
                    )
                }
            }
        }
    }
}

/**
 * 极简时长组件，防止整体重绘
 */
@Composable
fun DurationBadge(startTimeMillis: Long) {
    val durationText by produceState(initialValue = "...", startTimeMillis) {
        while (true) {
            val diffSeconds = (System.currentTimeMillis() - startTimeMillis) / 1000
            value = when {
                diffSeconds < 60 -> "${diffSeconds}s"
                diffSeconds < 3600 -> "${diffSeconds / 60}m"
                else -> "${diffSeconds / 3600}h"
            }
            kotlinx.coroutines.delay(1000)
        }
    }

    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
        shape = CircleShape
    ) {
        Text(
            text = durationText,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSecondaryContainer,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
        )
    }
}


@Composable
fun FullSettingsScreen(settings: SettingsManager, onPureBlackToggle: (Boolean) -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    
    // 核心配置状态：使用 null 初始值避免未加载时显示错误数据
    var config by remember { mutableStateOf<Map<String, Any>?>(null) }
    var coreVersion by remember { mutableStateOf("正在获取...") }

    // 初始化加载
    LaunchedEffect(Unit) {
        try {
            val v = RetrofitClient.instance.getVersion()
            coreVersion = v["version"]?.toString() ?: "Unknown"
            config = RetrofitClient.instance.getConfigs()
        } catch (e: Exception) { coreVersion = "获取失败" }
    }

    // 快捷更新函数：仅更新远程，不触发 UI 全局销毁
    fun updateRemoteConfig(key: String, value: Any) {
        scope.launch(Dispatchers.IO) {
            try {
                RetrofitClient.instance.updateConfigs(mapOf(key to value))
                // 仅局部更新本地变量，不触发全局 key 刷新
                config = config?.toMutableMap()?.apply { put(key, value) }
            } catch (e: Exception) {
                launch(Dispatchers.Main) { Toast.makeText(context, "更新失败", Toast.LENGTH_SHORT).show() }
            }
        }
    }

    // 如果 config 还没加载出来，显示加载中（避免布局抖动导致回到顶部）
    if (config == null) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        return
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // --- 1. 内核信息 ---
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(0.3f))) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("后端", fontWeight = FontWeight.Black)
                    }
                    Text(coreVersion, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                }
            }
        }
        
        item {
            Card(
                Modifier.fillMaxWidth(), 
                shape = RoundedCornerShape(16.dp), 
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(0.2f)) // 颜色改为更温和的 primaryContainer
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Terminal, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("核心控制", fontWeight = FontWeight.Black)
                    }
                    
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        // 重载配置按钮
                        Button(
                            onClick = { 
                                scope.launch(Dispatchers.IO) { 
                                    try { 
                                        // 根据 API 文档，PUT /configs 传 path 可以重载文件
                                        RetrofitClient.instance.reloadConfigs(mapOf("path" to "")) 
                                        launch(Dispatchers.Main){ Toast.makeText(context, "配置已重载", Toast.LENGTH_SHORT).show() }
                                    } catch (e: Exception){} 
                                } 
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            Icon(Icons.Default.Refresh, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("重载配置")
                        }
        
                        // 重启核心按钮
                        Button(
                            onClick = { 
                                scope.launch(Dispatchers.IO) { 
                                    try { 
                                        RetrofitClient.instance.restartCore()
                                        launch(Dispatchers.Main){ Toast.makeText(context, "核心已重启", Toast.LENGTH_SHORT).show() }
                                    } catch (e: Exception){} 
                                } 
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        ) {
                            Icon(Icons.Default.PowerSettingsNew, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("重启核心")
                        }
                    }
                }
            }
        }

        // --- 2. 基础端口配置 ---
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(0.3f))) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("网络端口", fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                    
                    val ports = listOf("mixed-port" to "混合端口", "port" to "HTTP 端口", "tproxy-port" to "Tproxy 端口", "socks-port" to "Socks 端口", "redir-port" to "Redir 端口")
                    ports.forEach { (key, label) ->
                        var textValue by remember(config) { mutableStateOf((config!![key] as? Double)?.toInt()?.toString() ?: "0") }
                        OutlinedTextField(
                            value = textValue,
                            onValueChange = { newValue ->
                                textValue = newValue
                                newValue.toIntOrNull()?.let { updateRemoteConfig(key, it) }
                            },
                            label = { Text(label) },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                    
                    var bindAddr by remember(config) { mutableStateOf(config!!["bind-address"]?.toString() ?: "*") }
                    OutlinedTextField(
                        value = bindAddr,
                        onValueChange = { bindAddr = it; updateRemoteConfig("bind-address", it) },
                        label = { Text("绑定地址") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }
        }

        // --- 3. TUN 模式配置 ---
        item {
            val tun = config!!["tun"] as? Map<String, Any>
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(0.3f))) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("TUN 模式", fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                    ConfigToggle("启用 TUN", tun?.get("enable") as? Boolean ?: false) { enabled ->
                        val newTun = tun?.toMutableMap() ?: mutableMapOf()
                        newTun["enable"] = enabled
                        updateRemoteConfig("tun", newTun)
                    }
                    if (tun?.get("enable") == true) {
                        Text("堆栈: ${tun["stack"] ?: "System"}", style = MaterialTheme.typography.labelSmall)
                        Text("设备名: ${tun["device"] ?: "unknown"}", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        // --- 4. 核心功能开关 ---
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(0.3f))) {
                Column(Modifier.padding(16.dp)) {
                    Text("内核设置", fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                    ConfigToggle("允许局域网", config!!["allow-lan"] as? Boolean ?: false) { updateRemoteConfig("allow-lan", it) }
                    ConfigToggle("IPv6 支持", config!!["ipv6"] as? Boolean ?: false) { updateRemoteConfig("ipv6", it) }
                    ConfigToggle("流量嗅探", config!!["sniffing"] as? Boolean ?: false) { updateRemoteConfig("sniffing", it) }
                    ConfigToggle("统一延迟", config!!["unified-delay"] as? Boolean ?: false) { updateRemoteConfig("unified-delay", it) }
                }
            }
        }

                // --- 5. UI 外观 (已修复实时更新 + 增加预览区) ---
        item {
            // 定义本地状态以驱动 UI 实时刷新
            var groupColBy by remember { mutableStateOf(if(settings.groupColumnCount == 1) "1 列" else "2 列") }
            var nodeColBy by remember { mutableStateOf(if(settings.columnCount == 1) "1 列" else "2 列") }
            var gBadgeStyle by remember { mutableStateOf(settings.groupBadgeStyle) }
            var dBadgeStyle by remember { mutableStateOf(settings.delayBadgeStyle) }
            var rBadgeStyle by remember { mutableStateOf(settings.ruleBadgeStyle) }
            var showGlobalBy by remember { mutableStateOf(settings.showGlobal) }
            var useSheetBy by remember { mutableStateOf(settings.useSheetMode) }
            var cardFillBy by remember { mutableStateOf(settings.cardFillStyle) }
            var radiusState by remember { mutableIntStateOf(settings.badgeCornerRadius) }
            var pureState by remember { mutableStateOf(settings.pureBlackMode) }
            var bgWs by remember { mutableStateOf(settings.backgroundWebSocket) }

            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(0.3f))) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("界面设置", fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                    
                    // --- 新增：实时预览区 ---
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .height(60.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(0.3f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            Modifier.fillMaxSize(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("代理组", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                Spacer(Modifier.height(4.dp))
                                TypeBadge("URL-TEST", gBadgeStyle, radiusState, false)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("延迟", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                Spacer(Modifier.height(4.dp))
                                DelayBadge(120, false, dBadgeStyle, radiusState, false) {}
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("规则", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                Spacer(Modifier.height(4.dp))
                                TypeBadge("FINAL", rBadgeStyle, radiusState, false)
                            }
                        }
                    }
                    
                    Spacer(Modifier.height(8.dp))
                    Text("Badge 圆角弧度: ${radiusState}dp", style = MaterialTheme.typography.labelSmall)
                    Slider(
                        value = radiusState.toFloat(), 
                        onValueChange = { 
                            radiusState = it.toInt()
                            settings.badgeCornerRadius = it.toInt()
                        }, 
                        valueRange = 0f..12f, 
                        steps = 12
                    )
                    
                    SettingsDropdownMenuInline("代理类型风格", gBadgeStyle, listOf("填充", "描边")) { 
                        gBadgeStyle = it
                        settings.groupBadgeStyle = it
                    }
                    SettingsDropdownMenuInline("延迟类型风格", dBadgeStyle, listOf("填充", "描边")) { 
                        dBadgeStyle = it
                        settings.delayBadgeStyle = it
                    }
                    SettingsDropdownMenuInline("规则类型风格", rBadgeStyle, listOf("填充", "描边")) { 
                        rBadgeStyle = it
                        settings.ruleBadgeStyle = it
                    }
                    
                    HorizontalDivider(Modifier.padding(vertical = 8.dp), thickness = 0.5.dp)
                    
                    SettingsDropdownMenuInline("代理组布局", groupColBy, listOf("1 列", "2 列")) { 
                        groupColBy = it
                        settings.groupColumnCount = if(it == "1 列") 1 else 2
                    }
                    SettingsDropdownMenuInline("节点网格列数", nodeColBy, listOf("1 列", "2 列")) { 
                        nodeColBy = it
                        settings.columnCount = if(it == "1 列") 1 else 2
                    }
                    
                    HorizontalDivider(Modifier.padding(vertical = 8.dp), thickness = 0.5.dp)

                    ConfigToggle("AMOLED 纯黑模式", pureState) { 
                        pureState = it
                        settings.pureBlackMode = it
                        onPureBlackToggle(it) 
                    }
                    
                    ConfigToggle("后台持续获取数据", bgWs) { 
                        bgWs = it
                        settings.backgroundWebSocket = it 
                    }

                    HorizontalDivider(Modifier.padding(vertical = 8.dp), thickness = 0.5.dp)
                    
                    ConfigToggle("显示 GLOBAL 代理组", showGlobalBy) { 
                        showGlobalBy = it
                        settings.showGlobal = it
                    }
                    ConfigToggle("点击开启底部抽屉模式", useSheetBy) { 
                        useSheetBy = it
                        settings.useSheetMode = it
                    }
                    ConfigToggle("代理卡片扁平填充风格", cardFillBy) { 
                        cardFillBy = it
                        settings.cardFillStyle = it
                    }
                }
            }
        }
    }
}


fun formatSize(b: Long): String = when { b < 1024 -> "${b}B"; b < 1048576 -> "${String.format("%.1f", b/1024f)}K"; else -> "${String.format("%.1f", b/1048576f)}M" }